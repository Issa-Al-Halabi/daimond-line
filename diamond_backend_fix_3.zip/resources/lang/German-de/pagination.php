<?php

return [

	'previous' => '&laquo; Früher',
	'next' => 'Nächster &raquo;',

];
