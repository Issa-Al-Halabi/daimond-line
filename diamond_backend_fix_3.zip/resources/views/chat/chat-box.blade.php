<div id="chat_box" class="chat_box pull-right" style="display: none">
    <div class="row">
        <div class="col-12 col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                        <h3 class="card-title"><span class="fa fa-comment"></span> Chat with <i class="chat-user"></i> </h3>
                        <span class="fa fa-remove pull-right close-chat"></span>
                    </div>
                    <div class="card-body chat-area">

                    </div>
                    <div class="card-footer">
                        <div class="input-group form-controls">
                            <textarea class="form-control input-sm chat_input" placeholder="Write your message here..."></textarea>
                            
                            <span class="input-group-btn">
                                    <button class="btn btn-primary btn-sm btn-chat" type="button" data-to-user="" disabled>
                                        
                                        <i class="fa fa-send"></i>
                                        Send</button>
                                </span>
                        </div>
                    </div>
                </div>
        </div>
    </div>
    <input type="hidden" id="to_user_id" value="" />
</div>