<?php

namespace App\Helpers;


use Exception;
use Illuminate\Http\Request;

class LogManager
{
    public function saveLog()
    {
        
    }
}