<?php

return [

	'previous' => '&laquo; I Meparshem',
	'next' => 'Tjetri &raquo;',

];
