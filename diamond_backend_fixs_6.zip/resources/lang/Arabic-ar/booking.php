<?php

return [
    "trip_accepted" => "تمت الموافقة على طلبك",
    "trip_arrived" => "وصل السائق",
    "trip_started" => "تم بدء الرحلة",
    "trip_wait_for_payment" => "بانتظار الدفع",
    "trip_ended" => "تم الانتهاء من الرحلة",
];