<?php

return [
    "not_found" => "الرحلة غير موجودة",
    "electronic_payment_error" => "حدث خطأ عند الاتصال مع بوابة الدفع الالكتروني",

    "accepted_payment_status_user" => "لقد دفعت الرحلة بنجاح",
    "accepted_payment_status_driver" => "تم دفع الرحلة بنجاح",

    "failed_payment_status_user" => "فشلت عملية الدفع",
    "failed_payment_status_driver" => "فشلت عملية الدفع",

    "canceled_payment_status_user" => "لقد الغيت الطلب",
    "canceled_payment_status_driver" => "تم الغاء الطلب",

    "payment_method" => "المستخدم اختار وسيلة الدفع التالية ",
    "payment_method_cash" => "المستخدم اختار الدفع نقداs",
    "payment_method_e_payment" => "المستخدم دفع عن طريق بوابة الدفع الالكترونية",

];
