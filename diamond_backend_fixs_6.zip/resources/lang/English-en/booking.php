<?php

return [
    "trip_accepted" => "Your Trip has been accepted",
    "trip_arrived" => "The Driver has arrived",
    "trip_started" => "Trip has started",
    "trip_wait_for_payment" => "Waiting for payment",
    "trip_ended" => "Trip ended",
];