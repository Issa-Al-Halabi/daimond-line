<?php

return [

	'previous' => '&laquo; Precendente',
	'next' => 'Sucessivo &raquo;',

];
