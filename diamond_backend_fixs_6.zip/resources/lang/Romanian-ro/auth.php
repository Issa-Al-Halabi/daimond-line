<?php

return [

	'failed' => 'Aceste acreditări nu corespund înregistrărilor noastre.',
	'throttle' => 'Prea multe încercări de autentificare. Încercați din nou în: secunde secunde.',

];
