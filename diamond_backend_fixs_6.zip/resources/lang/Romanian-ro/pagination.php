<?php

return [

	'previous' => '&laquo; Anterior',
	'next' => 'Next &raquo;',

];
